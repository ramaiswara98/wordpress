<?php

/*
Template Name: Blog
*/
?>
This is the Blog post template