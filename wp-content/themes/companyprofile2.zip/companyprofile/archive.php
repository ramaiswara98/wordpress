<?php get_header('home'); ?>

<div class="container">

    
    <?php get_template_part('includes/section','archive'); ?>
</div>


<?php get_footer();?>